package hw1

data class Process(
    val name: String,
    val priority: Int
)